import React from 'react'

const ChannelDetail = () => {
  return (
    <div>ChannelDetail</div>
  )
}

export default ChannelDetail