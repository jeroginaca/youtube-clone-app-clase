import React from 'react'

const VideoDetail = () => {
  return (
    <div>VideoDetail</div>
  )
}

export default VideoDetail